package com.package7.Springphase2;

import org.springframework.data.jpa.repository.JpaRepository;

public interface userrepository extends JpaRepository<User,Integer>{

}
