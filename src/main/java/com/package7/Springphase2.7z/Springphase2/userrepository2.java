package com.package7.Springphase2;


import org.springframework.data.repository.CrudRepository;

public interface userrepository2 extends CrudRepository<User,Integer>{

	
}
