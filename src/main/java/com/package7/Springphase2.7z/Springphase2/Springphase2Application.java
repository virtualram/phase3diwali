package com.package7.Springphase2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springphase2Application {

	public static void main(String[] args) {
		SpringApplication.run(Springphase2Application.class, args);
	}

}
