import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,HttpHeaderResponse } from "@angular/common/http";

import { Observable } from "rxjs";
import { User} from "./User";

@Injectable({
  providedIn: 'root'
})


export class MyserviceService {
  private url = 'http://127.0.0.1:8080/insertuser';
  constructor(private http: HttpClient) { }

  showTodayDate() {
    let ndate = new Date();
    return ndate;
 }
 CreateUser(user: User): Observable<any>{
  var httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json'})
  };
  console.log('value from service'+JSON.stringify(user));
  return this.http.post<User>(this.url,user,httpOptions);

  //other option
  /*
constructor(private http: HttpClient) {
    this.http.post(this.url, this.postData).toPromise().then((data:any) => {
      console.log(data.json);
    
      this.json = data.json;
    });
  }


  */

 
}
}
