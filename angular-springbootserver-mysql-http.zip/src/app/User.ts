export class User {

    public id: number = 0;

    public name: string ="";

    public password: string ="";

    public admin: boolean =false;

    public email: string ="";

    public confirmed: boolean=false;
}
